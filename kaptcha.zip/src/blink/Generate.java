package blink;

import com.google.code.kaptcha.Constants;
import java.util.Properties;

class Generate {

    public static void main(String args[]) {
        
        ImageGen gen = new ImageGen();
        gen.setTimestampFilename("timestamp");
        gen.setEnvironment(ImageGen.ENVIRONMENT_WINDOWS);
        gen.setImageFolder("img");
        gen.setImageDir();
        gen.setBimages(50); // generate 50 images.
        
        Properties prop = new Properties();
        prop.put(Constants.KAPTCHA_TEXTPRODUCER_FONT_NAMES, "Arial,Tahoma,Verdana");
        prop.put(Constants.KAPTCHA_IMAGE_WIDTH, "200");
        prop.put(Constants.KAPTCHA_IMAGE_HEIGHT, "50");
        prop.put(Constants.KAPTCHA_TEXTPRODUCER_CHAR_STRING, "BCEFGHJKMPQRTVWXY2346789");
        prop.put(Constants.KAPTCHA_TEXTPRODUCER_CHAR_LENGTH, "4");
        gen.setProperties(prop);
        
        gen.builder();
        
    }

}
