/**
 * @(#)ImageGen.java 1.0.0 2008-2-2 下午10:19:31
 *
 * Copyright (c) 2008 THCIC.  All rights reserved.
 *
 */
package blink;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.util.Date;
import java.util.Properties;

import javax.imageio.ImageIO;

import com.google.code.kaptcha.Producer;
import com.google.code.kaptcha.util.Config;
import java.io.UnsupportedEncodingException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Class ImageGen
 *
 * @author <a href="mailto:moogleo@gmail.com">Moogle Yang</a>
 * @version 1.0, 日期: 2008-2-2 关于本类的简单说明
 *
 */
public class ImageGen {

    //private WordGenerator wordGenerator = new WordGenerator("BCEFGHJKMPQRTVWXY2346789");

    private static Producer kaptchaProducer;

    private int bimages;

    private String imageFolder;

    private String path;

    private String timestampFilename;

    private String environment;

    private int length;

    public static final String ENVIRONMENT_LINUX = "linux";

    public static final String ENVIRONMENT_WINDOWS = "windows";

    
    public void setProperties(Properties properties){
        kaptchaProducer = new Config(properties).getProducerImpl();
    }

    public int getLength() {
        return length;
    }

    public void setLength(int len) {
        this.length = len;
    }

    public void setBimages(int bimages) {
        this.bimages = bimages;
    }

    public void removeAllImage() {
        for (File f : new File(path).listFiles()) {
            if (f.getName().contains("jpg")) {
                f.delete();
            }
        }
    }

    public void builder() {
        //this.removeAllImage();
        //logger.debug("开始生成验证码");
        for (int i = 0; i < bimages; i++) {
            //int wordLength = getRandomLength();
            //String word = getWordGenerator().getWord(wordLength);
            String word = kaptchaProducer.createText();
            BufferedImage image = null;
            try {
                image = kaptchaProducer.createImage(word);
                File imagefile = new File(path, word + ".jpg");
                FileOutputStream out = new FileOutputStream(imagefile);
                ImageIO.write(image, "JPEG", out);
                out.flush();
                out.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        //logger.debug("共计生成验证码图片张数:"+bimages);
        this.markTimestamp();
    }

    /**
     * 在文件上打上时间戳，标识图片已经更新了
     */
    private void markTimestamp() {
        //logger.debug("验证码生成完毕，打上最新的时间戳标记");
        File index = new File(path, timestampFilename);
        index.setLastModified(new Date().getTime());
        try {
            FileOutputStream out = new FileOutputStream(index);
            out.flush();
            out.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /*public void setWordGenerator(WordGenerator wordGenerator) {
        this.wordGenerator = wordGenerator;
    }*/

    /**
     * 设置构建验证码的路径,需要在linux下做一下路径的测试
     *
     * @return
     */
    public String setImageDir() {
        path = Thread.currentThread().getContextClassLoader().getResource("").toString();
        try {
            path = java.net.URLDecoder.decode(path, "UTF-8");
        } catch (UnsupportedEncodingException ex) {
            Logger.getLogger(ImageGen.class.getName()).log(Level.SEVERE, null, ex);
        }
        if (path.contains("classes")) {
            path = path.split("classes")[0] + this.imageFolder + File.separator;
            if (path.contains("file:")) {
                if (ENVIRONMENT_WINDOWS.equals(environment)) {
                    path = path.split("file:/")[1];
                } else if (ENVIRONMENT_LINUX.equals(environment)) {
                    path = path.split("file:")[1];
                }
            }
        }
        //logger.debug("验证码图片生成的存放位置在："+path);
        File file = new File(path);
        if (!file.exists()) {
            //logger.debug("生成放置图片的文件夹");
            file.mkdir();
        }
        return path;
    }

    private Integer getRandomLength() {
        if (Math.random() > 0.5d) {
            return 4;
        } else {
            return 5;
        }
    }

    public void setImageFolder(String imageFolder) {
        this.imageFolder = imageFolder;
    }

    public void setTimestampFilename(String timestampFilename) {
        this.timestampFilename = timestampFilename;
    }

    public void setEnvironment(String environment) {
        this.environment = environment;
    }

}
