/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package blink;

import java.util.Random;

/**
 *
 * @author xavieryao
 */
public class WordGenerator {
    final private String mCharset;
    
    public WordGenerator(String charset) {
        mCharset = charset;
    }
    
    public String getWord(int length) {
        StringBuilder sb = new StringBuilder();
        Random rnd = new Random();
        for (int i = 0; i < length; i++) {
            sb.append(mCharset.charAt(rnd.nextInt(mCharset.length())));
        }
        return sb.toString();
    }
}
